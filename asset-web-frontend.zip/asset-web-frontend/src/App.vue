<template>
  <div class="app-container">
    <!-- 顶部导航栏 -->
    <header class="app-header">
      <div class="header-content">
        <div class="logo">
          <el-icon :size="32"><DataAnalysis /></el-icon>
          <span class="logo-text">数据资产检索系统</span>
        </div>
        
        <el-menu
          :default-active="activeMenu"
          class="header-menu"
          mode="horizontal"
          @select="handleMenuSelect"
        >
          <el-menu-item index="emergency">
            <el-icon><Warning /></el-icon>
            <span>应急安全</span>
          </el-menu-item>
          <el-menu-item index="court" disabled>
            <el-icon><Document /></el-icon>
            <span>法院案件 (待开发)</span>
          </el-menu-item>
        </el-menu>
      </div>
    </header>

    <!-- 主内容区 -->
    <main class="app-main">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { DataAnalysis, Warning, Document } from '@element-plus/icons-vue'

const router = useRouter()
const activeMenu = ref('emergency')

const handleMenuSelect = (index) => {
  activeMenu.value = index
  router.push(`/${index}`)
}
</script>

<style scoped>
.app-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: radial-gradient(circle at 10% 20%, rgba(13, 17, 34, 0.8) 0%, rgba(5, 5, 17, 0.95) 100%);
}

.app-header {
  background: rgba(13, 17, 34, 0.8);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(15px);
  position: relative;
  z-index: 100;
}

.app-header::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--primary-color), transparent);
  box-shadow: 0 0 10px var(--primary-color);
  opacity: 0.7;
}

.header-content {
  max-width: 1600px;
  margin: 0 auto;
  padding: 0 32px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
  color: var(--primary-color);
  font-size: 22px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  filter: drop-shadow(0 0 5px rgba(0, 212, 255, 0.3));
}

.logo:hover {
  transform: scale(1.05);
  filter: drop-shadow(0 0 10px rgba(0, 212, 255, 0.6));
}

.logo-text {
  background: linear-gradient(135deg, #fff 0%, var(--primary-color) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  letter-spacing: 1px;
}

.header-menu {
  background: transparent !important;
  border: none !important;
  height: 64px;
}

:deep(.el-menu-item) {
  color: var(--text-secondary);
  border-bottom: 3px solid transparent;
  transition: all 0.3s ease;
  background: transparent !important;
  font-size: 15px;
  height: 64px;
  line-height: 64px;
}

:deep(.el-menu-item:hover) {
  color: #fff !important;
  text-shadow: 0 0 8px rgba(255, 255, 255, 0.5);
}

:deep(.el-menu-item.is-active) {
  color: var(--primary-color) !important;
  border-bottom-color: var(--primary-color) !important;
  background: rgba(0, 212, 255, 0.05) !important;
  text-shadow: 0 0 10px var(--primary-color);
}

.app-main {
  flex: 1;
  overflow: hidden;
  padding: 24px 32px;
  position: relative;
}

.app-main::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.02'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
  pointer-events: none;
  z-index: 0;
}

.app-main > * {
  position: relative;
  z-index: 1;
}
</style>
